Date: 2012-03-17 15:38
Author: Dylan

This branch contains network-level socket-related classes, defining hosts and messages.
