Please read the LICENSE.txt file before using EFS.

This release containts:

1) The source code of EFS (code folder)

2) A jar executable (execs folder)

For a short tutorial please visit: http://flexgp.github.io/efs/

