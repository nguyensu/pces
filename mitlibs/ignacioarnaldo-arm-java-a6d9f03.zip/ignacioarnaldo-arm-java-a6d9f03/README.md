arm-java
========

Java implementation of the Adaptive Regression by Mixing algorithm
as described in:

Yuhong Yang, Adaptive Regression by Mixing, Journal of American
Statistical Association, 96:454, 574-588, 2001.

See the "LICENSE" file for a copy of the license.  
