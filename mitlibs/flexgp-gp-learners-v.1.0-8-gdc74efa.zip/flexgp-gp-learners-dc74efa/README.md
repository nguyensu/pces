The code of the learners is divided into two Netbeans projects:

1) sr-rt-gpf: contains the source code for the SymbolicRegresion (SR), 
Rule Tree (RT), and GP Function (GPF) learners.

2) mrgp: contains the source code for the Multiple Regression Genetic Programming (MRGP) learner.
