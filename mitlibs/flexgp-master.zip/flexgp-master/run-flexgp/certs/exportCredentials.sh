#! /bin/bash

export EC2_HOME=
export PATH=$PATH:$EC2_HOME/bin
export AWS_ACCESS_KEY=
export AWS_SECRET_KEY=
#Java home for debian default install path:
export JAVA_HOME=/usr
