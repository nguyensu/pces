flexgp
======

Please read the LICENSE.txt file before using FlexGP.


This release contains:

1) run-flexgp: self-contained folder with all the scripts and executables necessary to run FlexGP

2) mrgp-flexgp: Java source code of MRGP, the core regression learner

3) comm-library: Java source code of the library that enables P2P communication between FlexGP cloud nodes


For instructions and an example of how to run FlexGP, please check the website:
http://flexgp.github.io/flexgp/

